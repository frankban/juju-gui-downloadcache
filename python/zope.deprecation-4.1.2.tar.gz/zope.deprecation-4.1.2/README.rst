``zope.deprecation``
====================

.. image:: https://travis-ci.org/zopefoundation/zope.deprecation.png?branch=master
        :target: https://travis-ci.org/zopefoundation/zope.deprecation

This package provides a simple function called ``deprecated(names, reason)``
to mark deprecated modules, classes, functions, methods and properties.

Please see http://docs.zope.org/zope.deprecation/ for the documentation.


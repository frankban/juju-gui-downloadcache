.. _html_api_documentation:

API Documentation
=================

Comprehensive reference material for every public API exposed by :app:`Pyramid`:

.. toctree::
   :maxdepth: 1
   :glob:

   *

.. _response_module:

:mod:`pyramid.response`
---------------------------

.. module:: pyramid.response

.. autoclass:: Response
   :members:
   :inherited-members:

.. autoclass:: FileResponse
   :members:

.. autoclass:: FileIter

Functions
~~~~~~~~~

.. autofunction:: response_adapter


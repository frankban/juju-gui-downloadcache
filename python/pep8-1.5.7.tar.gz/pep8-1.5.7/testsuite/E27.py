#: Okay
True and False
#: E271
True and  False
#: E272
True  and False
#: E271
if   1:
#: E273
True and		False
#: E273 E274
True		and	False
#: E271
a and  b
#: E271
1 and  b
#: E271
a and  2
#: E271 E272
1  and  b
#: E271 E272
a  and  2
#: E272
this  and False
#: E273
a and	b
#: E274
a		and b
#: E273 E274
this		and	False

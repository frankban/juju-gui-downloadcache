#: W391:2:1
# The next line is blank

#: W391:3:1
# Two additional empty lines


#: W391:4:1 W293:3:1 W293:4:1 noeol
# The last lines contain space

    
    
#: Okay
'''there is nothing wrong
with a multiline string at EOF

that happens to have a blank line in it
'''

.. _pyramid_mako_api:

:mod:`pyramid_mako` API
-------------------------

.. automodule:: pyramid_mako

.. autofunction:: includeme

.. autofunction:: add_mako_renderer

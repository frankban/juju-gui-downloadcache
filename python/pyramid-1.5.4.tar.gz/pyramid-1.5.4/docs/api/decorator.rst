.. _decorator_module:

:mod:`pyramid.decorator`
--------------------------

.. automodule:: pyramid.decorator

.. autofunction:: reify


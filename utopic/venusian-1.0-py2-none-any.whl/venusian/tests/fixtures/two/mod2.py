from .mod1 import Class
